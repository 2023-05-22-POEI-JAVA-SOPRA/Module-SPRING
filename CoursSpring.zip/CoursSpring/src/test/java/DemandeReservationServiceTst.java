import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Reservation;
import fr.coursspring.service.DemandeReservationService;
import fr.coursspring.service.ReservationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.time.LocalDate;

@SpringJUnitConfig(ApplicationConfig.class)
public class DemandeReservationServiceTst {

    @Autowired
    private DemandeReservationService reservationService;

    @Test
    public void test_service_save_hotel_super()
    {
        DemandeReservation demande = new DemandeReservation("Reservation", LocalDate.now(), LocalDate.now().plusDays(3), "Monacow city plage", "super Hotel Formule 1");

        Reservation resa = reservationService.DemandeReservation(demande);

        Assertions.assertNull(resa);
    }

    @Test
    public void test_service_save_hotel_non_super()
    {
        DemandeReservation demande = new DemandeReservation("Reservation", LocalDate.now(), LocalDate.now().plusDays(3), "Monacow city plage", "Hotel Formule 1");

        Reservation resa = reservationService.DemandeReservation(demande);

        Assertions.assertNotNull(resa);
    }

    @Test
    public void test_service_save_plage_incorrect()
    {
        DemandeReservation demande = new DemandeReservation("Reservation", LocalDate.now(), LocalDate.now().plusDays(3), "Monacow city", "Hotel Formule 1");

        Reservation resa = reservationService.DemandeReservation(demande);

        Assertions.assertNull(resa);
    }

    @Test
    public void test_service_save_plage_correct()
    {
        DemandeReservation demande = new DemandeReservation("Reservation", LocalDate.now(), LocalDate.now().plusDays(3), "Monacow city plage", "Hotel Formule 1");

        Reservation resa = reservationService.DemandeReservation(demande);

        Assertions.assertNotNull(resa);
    }

}
