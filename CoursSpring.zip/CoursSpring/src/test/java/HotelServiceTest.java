import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.entity.Hotel;
import fr.coursspring.entity.Reservation;
import fr.coursspring.service.HotelService;
import fr.coursspring.service.PlageService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.time.LocalDate;

@SpringJUnitConfig(ApplicationConfig.class)
public class HotelServiceTest {

    @Autowired
    private HotelService hotelService;

    @Test
    public void test_service_is_not_null()
    {
        Assertions.assertNotNull(hotelService);
    }

    @Test
    public void test_dao_is_not_null()
    {
        Assertions.assertNotNull(hotelService.hotelDAO);
    }


    @Test
    public void test_service_get()
    {

        Integer id = 1;

        Assertions.assertNotEquals(hotelService.get(id), "");
    }

    @Test
    public void test_service_save()
    {
        Hotel hotel = new Hotel(1, "reservation1", "Monacow");
        Assertions.assertNotNull(hotel);
    }
}
