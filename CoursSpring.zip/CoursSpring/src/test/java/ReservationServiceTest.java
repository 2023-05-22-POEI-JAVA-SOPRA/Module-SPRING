import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Plage;
import fr.coursspring.entity.Reservation;
import fr.coursspring.service.FirstService;
import fr.coursspring.service.ReservationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.time.LocalDate;

@SpringJUnitConfig(ApplicationConfig.class)
public class ReservationServiceTest {

    @Autowired
    private ReservationService reservationService;

    @Test
    public void test_service_is_not_null()
    {
        Assertions.assertNotNull(reservationService);
    }

    @Test
    public void test_dao_is_not_null()
    {
        Assertions.assertNotNull(reservationService.reservationDAO);
    }

    @Test
    public void test_service_get()
    {

        Integer id = 1;

        Assertions.assertNotEquals(reservationService.get(id), "");
    }

    @Test
    public void test_service_save()
    {
        Reservation resa = new Reservation(1, "reservation1", LocalDate.now(), LocalDate.now().plusDays(3));
        Assertions.assertNotNull(resa);
    }


}
