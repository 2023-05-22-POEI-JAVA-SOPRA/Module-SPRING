import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.service.FirstService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(ApplicationConfig.class)
public class FirstServiceTest {

    @Autowired
    private FirstService firstService;

    @Test
    public void Test(){

        String message = "Coucou";

        Assertions.assertNotNull(message);

        Assertions.assertNotNull(firstService.getId());

    }

}
