import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.entity.Plage;
import fr.coursspring.service.PlageService;
import fr.coursspring.service.ReservationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(ApplicationConfig.class)
public class PlageServiceTest {

    @Autowired
    private PlageService plageService;

    @Test
    public void test_service_is_not_null()
    {
        Assertions.assertNotNull(plageService);
    }

    @Test
    public void test_service_get()
    {

        Integer id = 1;

        Assertions.assertNotEquals(plageService.get(id), "");
    }

    @Test
    public void test_dao_is_not_null()
    {
        Assertions.assertNotNull(plageService.plageDAO);
    }

    @Test
    public void test_service_save()
    {
        Plage plage = new Plage(1, "plage");
        Assertions.assertNotNull(plage);
    }

}
