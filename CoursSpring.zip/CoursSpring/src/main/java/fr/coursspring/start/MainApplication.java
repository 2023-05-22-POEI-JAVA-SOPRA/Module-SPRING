package fr.coursspring.start;

import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Hotel;
import fr.coursspring.entity.Plage;
import fr.coursspring.entity.Reservation;
import fr.coursspring.service.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.time.LocalDate;

@SpringBootApplication
public class MainApplication {

    public static void main(String[] args) {

        ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

        ReservationService rs = context.getBean("BeanReservationService", ReservationService.class);
        HotelService hs = context.getBean("BeanHotelService", HotelService.class);
        PlageService ps = context.getBean("BeanPlageService", PlageService.class);
        DemandeReservationService drs = context.getBean("BeanDemandeReservationService", DemandeReservationService.class);

        System.out.println(rs.save(new Reservation(5, "ResaSave", LocalDate.now(), LocalDate.now().plusDays(3))));
        System.out.println(rs.get(15));


        System.out.println(hs.save(new Hotel(5, "HotelSave", "Monacow")));
        System.out.println(hs.get(56));


        System.out.println(ps.save(new Plage(5, "Monacow city plage")));
        System.out.println(ps.get(61));

        System.out.println(drs.DemandeReservation(new DemandeReservation("Reservation", LocalDate.now(), LocalDate.now().plusDays(3), "Monacow city plage", "Hotel Formule 1")));

    }

}
