package fr.coursspring.config;

import fr.coursspring.service.*;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan("fr.coursspring")
@PropertySource("classpath:application.properties")
@Scope("singleton")
public class ApplicationConfig {

    @Bean
    public FirstService BeanFirstService(){

        FirstService service = new FirstService();
        service.setId(15);

        return service;
    }

    @Bean
    public SecondService BeanSecondService(){
        return new SecondService();
    }

    @Bean
    public ReservationService BeanReservationService(){
        return new ReservationService();
    }

    @Bean
    public HotelService BeanHotelService(){
        return new HotelService();
    }

    @Bean
    public PlageService BeanPlageService(){
        return new PlageService();
    }

    @Bean
    public DemandeReservationService BeanDemandeReservationService(){
        return new DemandeReservationService();
    }
}
