package fr.coursspring.service;

import fr.coursspring.entity.Plage;
import fr.coursspring.entity.Reservation;
import fr.coursspring.repository.HotelDAO;
import fr.coursspring.repository.PlageDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class PlageService {

    @Autowired
    public PlageDAO plageDAO;

    public Plage save(Plage plage){

        return plageDAO.save(plage);

    }

    public String get(Integer id){
        return plageDAO.get(id);
    }

}
