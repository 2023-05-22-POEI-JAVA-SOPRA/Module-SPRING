package fr.coursspring.service;

import fr.coursspring.entity.Hotel;
import fr.coursspring.entity.Plage;
import fr.coursspring.repository.HotelDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HotelService {

    @Autowired
    public HotelDAO hotelDAO;

    public Hotel save(Hotel hotel){

        return hotelDAO.save(hotel);

    }

    public String get(Integer id){

        return hotelDAO.get(id);

    }


}
