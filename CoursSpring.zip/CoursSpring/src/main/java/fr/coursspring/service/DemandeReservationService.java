package fr.coursspring.service;

import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Reservation;
import fr.coursspring.repository.ReservationDAO;
import org.springframework.beans.factory.annotation.Autowired;

public class DemandeReservationService {

    @Autowired
    private ReservationDAO reservationDAO;

    public Reservation DemandeReservation(DemandeReservation demandeReservation){

        return reservationDAO.DemandeReservation(demandeReservation);

    }

}
