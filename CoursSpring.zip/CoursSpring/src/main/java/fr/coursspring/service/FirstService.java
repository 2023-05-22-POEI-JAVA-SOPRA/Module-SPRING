package fr.coursspring.service;

import fr.coursspring.config.ApplicationConfig;
import fr.coursspring.repository.FirstDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class FirstService {

    @Autowired
    public FirstDAO FDAO;

    @Value(value = "${FirstService.id}")
    private Integer id;

    public void coucou(String message){
        System.out.println(message);
    }


    public FirstDAO getFDAO() {
        return FDAO;
    }

    public void setFDAO(FirstDAO FDAO) {
        this.FDAO = FDAO;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
