package fr.coursspring.service;


import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Reservation;
import fr.coursspring.repository.PlageDAO;
import fr.coursspring.repository.ReservationDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ReservationService {

    @Autowired
    public ReservationDAO reservationDAO;

    public Reservation save(Reservation reservation){

        return reservationDAO.save(reservation);

    }

    public String get(Integer id){
        return reservationDAO.get(id);
    }


    public Reservation DemandeReservation(DemandeReservation demandeReservation){

        return reservationDAO.DemandeReservation(demandeReservation);

    }
}
