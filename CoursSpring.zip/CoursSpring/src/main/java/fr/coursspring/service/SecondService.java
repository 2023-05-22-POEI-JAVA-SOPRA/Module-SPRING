package fr.coursspring.service;

import fr.coursspring.repository.FirstDAO;
import fr.coursspring.repository.SecondDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SecondService {

    @Autowired
    public SecondDAO SDAO;

    public void coucou(){
        System.out.println("Coucou second service");
    }
}
