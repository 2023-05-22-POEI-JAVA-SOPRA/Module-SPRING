package fr.coursspring.repository;

import fr.coursspring.entity.Hotel;
import org.springframework.stereotype.Repository;

@Repository
public class HotelDAO {

    public Hotel save(Hotel reservation){

        return reservation;

    }

    public String get(Integer id){
        return new Hotel(id, "HotelGet", "VilleHotelGet").toString();
    }



}
