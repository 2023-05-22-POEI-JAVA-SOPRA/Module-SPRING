package fr.coursspring.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
public class FirstDAO {

    public void coucou(){
        System.out.println("Coucou DAO");
    }

}
