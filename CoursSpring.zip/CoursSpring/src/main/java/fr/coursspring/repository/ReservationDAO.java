package fr.coursspring.repository;

import fr.coursspring.entity.DemandeReservation;
import fr.coursspring.entity.Reservation;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public class ReservationDAO {

    public Reservation save(Reservation reservation){

        return reservation;

    }

    public String get(Integer id){
        return new Reservation(id, "reservationGet", LocalDate.now(), LocalDate.now().plusDays(3)).toString();
    }

    public Reservation DemandeReservation(DemandeReservation demandeReservation){

        if(demandeReservation.getHotel().toLowerCase().contains("super"))
        {
            return null;
        }

        if(!demandeReservation.getPlage().toLowerCase().endsWith("plage"))
        {
            return null;
        }

        Reservation reservation = new Reservation(5, demandeReservation.getNom(), demandeReservation.getDebut(), demandeReservation.getFin());

        return reservation;

    }

}
