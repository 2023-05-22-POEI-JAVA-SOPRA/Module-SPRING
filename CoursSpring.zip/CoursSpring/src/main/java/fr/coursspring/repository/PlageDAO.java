package fr.coursspring.repository;

import fr.coursspring.entity.Plage;
import org.springframework.stereotype.Repository;

@Repository
public class PlageDAO {

    public Plage save(Plage reservation){

        return reservation;

    }

    public String get(Integer id){
        return new Plage(id, "PlageGet").toString();
    }


}
