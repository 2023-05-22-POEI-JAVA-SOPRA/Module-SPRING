package fr.coursspring.repository;

import org.springframework.stereotype.Repository;

@Repository
public class SecondDAO {

    public void coucou(){
        System.out.println("Coucou second DAO");
    }

}
